import useInfo from './getinfo';

export {
    useInfo
};