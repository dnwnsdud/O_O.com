import React from 'react';
import { View, Text } from 'react-native';
export default ()=>{
    return <View>
        <Text>에러</Text>
    </View>
}