import React from 'react';
import { View, Text } from 'react-native';
export default ()=>{
    return <View>
        <Text>로딩중...</Text>
    </View>
}